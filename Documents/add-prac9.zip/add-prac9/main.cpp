#include "myStack.h"
#include "RPN.h"
#include <iostream>
#include <string>

using namespace std;

int main()
{
	int returned;
	myStack the_stack;
	the_stack.push(3);
	the_stack.push(4);
	the_stack.push(5);


	//cout << the_stack.pop();
	//cout << the_stack.pop();
	//cout << the_stack.pop();
	
	vector<string> myVec;
	myVec.push_back("*");
	//myVec.push_back("-");
	myVec.push_back("5");
	//myVec.push_back("6");
	//myVec.push_back("7");
	
	//string str = "*";
	RPN myRPN(myVec);
	myRPN.execute();
	//cout << myRPN.check_operator(str);
	//cout << myRPN.check_num(str);

}
