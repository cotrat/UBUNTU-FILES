#include "RPN.h"
#include <ctype.h>
#include <vector>
#include <string>
#include <cstdlib>
#include <iostream>

using namespace std;

RPN::RPN(vector<string> input_values)
{
	values = input_values;
}

RPN::RPN()
{

}

RPN::~RPN()
{

}

int RPN::execute()
{
	int oper1;
	int oper2;
	bool work = 1;

	for(int i = values.size() -1 ; i >= 0; --i)
	{
		if (check_num(values[i]))
		{
			the_stack.push(atoi(values[i].c_str()));
			//cout << atoi(values[i].c_str()) + 1;
		}
		if (check_operator(values[i]))
		{
		
			oper1 = the_stack.pop();
			oper2 = the_stack.pop();

			/*if(the_stack.size == 0)
			{
				//cout << "error";
				work = 0;
				break;
			}*/

			if( values[i] == "+" )
			{
				the_stack.push(oper1+oper2);
			}
			else if( values[i] == "-" )
			{
				the_stack.push(oper1-oper2);
			}
			else if( values[i] == "*" )
			{
				the_stack.push(oper1*oper2);
			}
			else if( values[i] == "/" )
			{
				the_stack.push(oper1/oper2);
			}

		}
	}

	/*if(the_stack.size > 1 or work == 0)
	{
		cout << "error";//the_stack.pop();
	}
	else
	{*/
		cout << the_stack.pop();
	//}
	
}

bool RPN::check_operator(string the_word)
{
	if (the_word == "*" or the_word == "/" or the_word == "+" or the_word == "-")
	{
		return 1;
	}
	return 0;
}

bool RPN::check_num(string the_word)
{
	bool num = 1;

	for(unsigned int i = 0; i < the_word.length(); i++)
	{
		if( !isdigit(the_word[i]) )
		{
			num = 0;
			break;
		}
	}

	return num;
	
}
