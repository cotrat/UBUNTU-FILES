#ifndef _assert
#define _assert

void assert(int ok, char* errMsg);

#endif
