#include <stdio.h>
int main(int argc, char** argv)
{
  int x= 3;
  int* p;
int *j;

  printf ("x=%d\n",x);
  printf("p->%d\n",*p);
	printf("j->%d\n",*j);
  return 0;
}
