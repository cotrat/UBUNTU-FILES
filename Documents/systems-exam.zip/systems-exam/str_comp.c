#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void)
{
	char* word = "word1";
	char* word2 = "word2";

}

int mystrcmp(char* s1, char* s2)
{
	if(*s1 != *s2)
	{
		return 0;
	}
	else if(*s1 == '\0' && 

}
