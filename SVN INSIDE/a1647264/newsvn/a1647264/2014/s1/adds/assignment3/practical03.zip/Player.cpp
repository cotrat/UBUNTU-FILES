#include <string>
#include <iostream>
#include "Player.h"

using namespace std;

Player::Player(){
}

Player::Player(string name2)
{
	name = name2;
}

Player::~Player(){
}

string Player::getName()
{
	return name;
}

void Player::setCtr(int ctr)
{
	
}

void Player::addAnswer(string ans)
{
	
}

string Player::performMove()
{
	return "";
}


