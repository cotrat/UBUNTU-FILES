#ifndef PALINDROME_H
#define PALINDROME_H
#include <string>
#include <vector>


class Palindrome {
	public:
		Palindrome();
		std::string reverse(std::string);
		bool isPalindrome(std::string);
		~Palindrome();
		
	private:
		
	
		
};

#endif
